import {rolldown} from 'rolldown';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('../',import.meta.url));
const bundle=await rolldown({input:path.join(root,'app/browser-entry.tsx'),platform:'browser',transform:{jsx:'react-jsx',define:{'process.env.NODE_ENV':'"production"'}}});
try{
 const {output}=await bundle.generate({format:'iife',minify:true});
 const css=fs.readFileSync(path.join(root,'app/globals.css'),'utf8').replace('@import "tailwindcss";','');
 const script=output.find(item=>item.type==='chunk').code.replace(/<\/script/gi,'<\\/script');
 const icon=fs.readFileSync(path.join(root,'public/favicon.svg'),'utf8');
 const html='<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="课件本地归档、学术资料检索与常用 AI 工具导航。"><title>研习 · 我的研究生学习空间</title><link rel="icon" href="data:image/svg+xml,'+encodeURIComponent(icon)+'"><style>'+css+'</style></head><body><div id="root"></div><script>'+script+'</script></body></html>';
 fs.mkdirSync(path.join(root,'dist'),{recursive:true});
 fs.writeFileSync(path.join(root,'dist/index.html'),html);
 console.log('Static study space built. Data stays in the current browser.');
}finally{await bundle.close();}
