import http from 'node:http';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
const page=fileURLToPath(new URL('../dist/index.html',import.meta.url));
const port=Number(process.env.GRADSPACE_PORT||4176);
http.createServer((req,res)=>{
 const pathname=new URL(req.url,'http://127.0.0.1').pathname;
 if(!['/','/index.html'].includes(pathname)){res.writeHead(404);res.end();return;}
 res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
 res.end(fs.readFileSync(page));
}).listen(port,'127.0.0.1',()=>console.log('Local: http://127.0.0.1:'+port+' (process '+process.pid+')'));
