CREATE TABLE `courses` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`name` text NOT NULL,
	`semester` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `courses_owner` ON `courses` (`owner`);--> statement-breakpoint
CREATE TABLE `resources` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`title` text NOT NULL,
	`kind` text NOT NULL,
	`course` text DEFAULT '' NOT NULL,
	`category` text DEFAULT '' NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`url` text DEFAULT '' NOT NULL,
	`object_key` text DEFAULT '' NOT NULL,
	`size` integer DEFAULT 0 NOT NULL,
	`mime` text DEFAULT '' NOT NULL,
	`favorite` integer DEFAULT 0 NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `resources_owner` ON `resources` (`owner`);