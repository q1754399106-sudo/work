import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const courses = sqliteTable('courses', {id:text('id').primaryKey(),owner:text('owner').notNull(),name:text('name').notNull(),semester:text('semester').notNull(),created:text('created').notNull()},t=>[index('courses_owner').on(t.owner)]);
export const resources = sqliteTable('resources', {
id:text('id').primaryKey(),owner:text('owner').notNull(),title:text('title').notNull(),kind:text('kind').notNull(),course:text('course').notNull().default(''),category:text('category').notNull().default(''),note:text('note').notNull().default(''),url:text('url').notNull().default(''),objectKey:text('object_key').notNull().default(''),size:integer('size').notNull().default(0),mime:text('mime').notNull().default(''),favorite:integer('favorite').notNull().default(0),created:text('created').notNull()
},t=>[index('resources_owner').on(t.owner)]);
