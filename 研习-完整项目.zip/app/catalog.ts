export const aiTools=[
{"name":"Gemini","initial":"✦","color":"#547fe6","category":"综合问答","desc":"Google AI 助手，辅助学习、讨论与创作","url":"https://gemini.google.com/"},
{"name":"豆包","initial":"豆","color":"#78a6d2","category":"综合问答","desc":"中文对话、学习问答与创意辅助","url":"https://www.doubao.com/"},
{"name":"Claude","initial":"C","color":"#c48367","category":"写作整理","desc":"长文阅读、写作与代码讨论","url":"https://claude.ai/"},
{"name":"千问","initial":"千","color":"#8570d5","category":"综合问答","desc":"阿里 AI 助手 · 原通义千问","url":"https://www.qianwen.com/"},
{"name":"腾讯元宝","initial":"元","color":"#5da889","category":"综合问答","desc":"学习问答与日常创作辅助","url":"https://yuanbao.tencent.com/"},
{"name":"Microsoft Copilot","initial":"M","color":"#618faa","category":"综合问答","desc":"微软 AI 助手，探索想法与解答问题","url":"https://copilot.microsoft.com/"},
{"name":"Qwen Chat","initial":"Q","color":"#7664c5","category":"编程助手","desc":"通义模型对话与代码辅助入口","url":"https://chat.qwen.ai/"},
{"name":"DeepL Write","initial":"W","color":"#385a75","category":"写作整理","desc":"外语表达改进与写作润色","url":"https://www.deepl.com/write"},

{name:'ChatGPT',initial:'◎',color:'#177b68',category:'综合问答',desc:'梳理概念、讨论思路与辅助写作',url:'https://chatgpt.com/'},
{name:'DeepSeek',initial:'D',color:'#4e6ef2',category:'综合问答',desc:'中文问答、推理与代码辅助',url:'https://chat.deepseek.com/'},
{name:'Kimi',initial:'K',color:'#20242d',category:'论文阅读',desc:'阅读长文档，整理资料与观点',url:'https://www.kimi.com/'},
{name:'Perplexity',initial:'✳',color:'#27848a',category:'学术搜索',desc:'带来源的搜索，探索研究线索',url:'https://www.perplexity.ai/'},
{name:'Elicit',initial:'e',color:'#8872ad',category:'学术搜索',desc:'检索论文、提取与整理研究证据',url:'https://elicit.com/'},
{name:'Consensus',initial:'C',color:'#3e67ab',category:'学术搜索',desc:'从研究文献中查找问题的答案',url:'https://consensus.app/'},
{name:'Gemini Notebook',initial:'N',color:'#446443',category:'论文阅读',desc:'原 NotebookLM · 围绕资料阅读与提问',url:'https://notebook.google/'},
{name:'Zotero',initial:'Z',color:'#b34e41',category:'写作整理',desc:'文献管理与引用整理（非 AI 工具）',url:'https://www.zotero.org/'}
];
export const academic=[
{name:'Google Scholar',cn:'谷歌学术',desc:'跨学科文献与引用检索',url:'https://scholar.google.com/',initial:'G'},
{name:'中国知网',cn:'CNKI',desc:'中文期刊、学位论文与会议论文',url:'https://www.cnki.net/',initial:'知'},
{name:'Semantic Scholar',cn:'语义学术',desc:'论文检索与相关研究探索',url:'https://www.semanticscholar.org/',initial:'S'},
{name:'arXiv',cn:'开放预印本',desc:'浏览开放获取的研究预印本',url:'https://arxiv.org/',initial:'a'}
];
