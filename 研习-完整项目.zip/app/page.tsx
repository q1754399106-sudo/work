import Desk from './study-desk';export default function Home(){return <Desk/>;}
