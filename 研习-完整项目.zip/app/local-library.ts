type Row=Record<string,any>;
function openDB():Promise<IDBDatabase>{return new Promise((resolve,reject)=>{const req=indexedDB.open('gradspace-local-v1',1);req.onupgradeneeded=()=>{req.result.createObjectStore('courses',{keyPath:'id'});req.result.createObjectStore('resources',{keyPath:'id'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(Error('无法打开本地资料库，请检查浏览器存储权限。'));});}
async function transaction(store:string,mode:IDBTransactionMode,run:(s:IDBObjectStore)=>IDBRequest):Promise<any>{const db=await openDB();return new Promise((resolve,reject)=>{const tx=db.transaction(store,mode);const req=run(tx.objectStore(store));tx.oncomplete=()=>{resolve(req.result);db.close();};tx.onerror=()=>{reject(Error('保存失败，可能是浏览器存储空间不足。请保留原文件。'));db.close();};tx.onabort=tx.onerror;});}
export async function localRead(){const [courses,resources]=await Promise.all([transaction('courses','readonly',s=>s.getAll()),transaction('resources','readonly',s=>s.getAll())]);return {courses:courses.sort((a:Row,b:Row)=>b.created.localeCompare(a.created)),resources:resources.sort((a:Row,b:Row)=>b.created.localeCompare(a.created)).map((r:Row)=>({...r,localUrl:r.file?URL.createObjectURL(r.file):undefined,file:undefined}))};}
export async function localUpload(file:File,course:string,note:string){const row={id:crypto.randomUUID(),title:file.name,kind:'file',course,category:file.name.split('.').pop()?.toLowerCase(),note,url:'',size:file.size,favorite:0,created:new Date().toISOString(),file};await transaction('resources','readwrite',s=>s.add(row));return row.id;}
export async function localMutate(method:string,body:Row){
const store=body.kind==='course'?'courses':'resources';
if(method==='POST'){const row={created:new Date().toISOString(),course:'',note:'',favorite:0,size:0,...body,id:crypto.randomUUID()};await transaction(store,'readwrite',s=>s.add(row));return {id:row.id};}
if(method==='PATCH'){const row=await transaction('resources','readonly',s=>s.get(body.id));if(!row)throw Error('资料不存在。');const updated=body.action==='edit'?{...row,title:body.title,url:body.url,category:body.category,note:body.note}:{...row,favorite:body.favorite?1:0};await transaction('resources','readwrite',s=>s.put(updated));return {ok:true};}
if(method==='DELETE'){if(store==='courses'){const rows=await transaction('resources','readonly',s=>s.getAll());for(const row of rows.filter((r:Row)=>r.course===body.id))await transaction('resources','readwrite',s=>s.put({...row,course:''}));}await transaction(store,'readwrite',s=>s.delete(body.id));return {ok:true};}
throw Error('不支持的操作。');
}

