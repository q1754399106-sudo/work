import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../../chatgpt-auth';
export const dynamic='force-dynamic';
export async function GET(req:Request,context:{params:Promise<{id:string}>}){
const user=await getChatGPTUser();if(!user)return new Response('请先登录',{status:401});
try{const {id}=await context.params;
const row=await env.DB!.prepare('SELECT object_key,title,category FROM resources WHERE id=? AND owner=? AND kind=?').bind(id,user.userId,'file').first<{object_key:string,title:string,category:string}>();
if(!row)return new Response('文件不存在',{status:404});
const object=await env.BUCKET!.get(row.object_key);if(!object)return new Response('文件不存在',{status:404});
const preview=new URL(req.url).searchParams.get('preview')==='1'&&row.category==='pdf';
return new Response(object.body,{headers:{'Content-Type':preview?'application/pdf':'application/octet-stream','Content-Disposition':(preview?'inline':'attachment')+"; filename*=UTF-8''"+encodeURIComponent(row.title),'Content-Length':String(object.size),'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':'sandbox'}});
}catch{return new Response('读取失败，请稍后重试',{status:500});}
}
