import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../../chatgpt-auth';
export const dynamic='force-dynamic';
const reply=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
const clean=(v:unknown,max=200)=>typeof v==='string'?v.trim().slice(0,max):'';
const fail=()=>reply({error:'暂时无法保存，请稍后重试。'},500);
async function identity(req:Request){
if(req.method!=='GET'&&req.headers.get('origin')&&new URL(req.url).origin!==req.headers.get('origin'))return null;
return getChatGPTUser();
}
export async function GET(req:Request){
const user=await identity(req);if(!user)return reply({error:'请先登录后使用云端资料库。'},401);
try{
const [courses,resources]=await Promise.all([
env.DB!.prepare('SELECT * FROM courses WHERE owner=? ORDER BY created DESC').bind(user.userId).all(),
env.DB!.prepare('SELECT id,title,kind,course,category,note,url,size,mime,favorite,created FROM resources WHERE owner=? ORDER BY created DESC').bind(user.userId).all()]);
return reply({courses:courses.results,resources:resources.results});
}catch{return fail();}
}
export async function POST(req:Request){
const user=await identity(req);if(!user)return reply({error:'请先登录后使用云端资料库。'},401);
try{
const id=crypto.randomUUID(),created=new Date().toISOString();
if(req.headers.get('content-type')?.split(';')[0]==='application/octet-stream'){
const decodeHeader=(name:string)=>{try{return decodeURIComponent(req.headers.get(name)||'');}catch{return '';}};
const title=clean(decodeHeader('x-file-name'));
const length=Number(req.headers.get('x-file-size'));
if(!title||!req.body||!Number.isSafeInteger(length)||length<=0)return reply({error:'请选择有效的非空文件。'},400);
const extension=title.split('.').pop()?.toLowerCase();
if(!['pdf','ppt','pptx','doc','docx','xls','xlsx','txt','md','csv','zip','png','jpg','jpeg'].includes(extension||''))return reply({error:'暂不支持此格式，请上传常见文档、图片或 ZIP 文件。'},400);
const course=clean(decodeHeader('x-file-course')),note=clean(decodeHeader('x-file-note'),2000);
if(course&&!await env.DB!.prepare('SELECT id FROM courses WHERE id=? AND owner=?').bind(course,user.userId).first())return reply({error:'课程不存在，请重新选择。'},400);
const key='files/'+user.userId+'/'+id;
// Stream the request directly into object storage; do not buffer the entire file.
const object=await env.BUCKET!.put(key,req.body,{httpMetadata:{contentType:'application/octet-stream'}});
if(!object)return reply({error:'文件未保存，请重试。'},500);
if(object.size!==length){await env.BUCKET!.delete(key);return reply({error:'文件传输不完整，请重新上传。'},400);}
try{await env.DB!.prepare('INSERT INTO resources (id,owner,title,kind,course,category,note,url,object_key,size,mime,favorite,created) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(id,user.userId,title,'file',course,extension,note,'',key,object.size,'application/octet-stream',0,created).run();}
catch(e){await env.BUCKET!.delete(key);throw e;}
return reply({id},201);
}
const body=await req.json() as Record<string,unknown>;
if(body.kind==='course'){
const name=clean(body.name,80),semester=clean(body.semester,50);
if(!name||!semester)return reply({error:'请填写课程名称和学期。'},400);
await env.DB!.prepare('INSERT INTO courses (id,owner,name,semester,created) VALUES (?,?,?,?,?)').bind(id,user.userId,name,semester,created).run();
}else if((body.kind==='link'||body.kind==='tool')){
const title=clean(body.title),url=clean(body.url,2000);
let parsed:URL;try{parsed=new URL(url);}catch{return reply({error:'请输入完整的网址（以 https:// 开头）。'},400);}
if(!title||!['https:','http:'].includes(parsed.protocol))return reply({error:'请填写标题和有效网址。'},400);
await env.DB!.prepare('INSERT INTO resources (id,owner,title,kind,category,note,url,created) VALUES (?,?,?,?,?,?,?,?)').bind(id,user.userId,title,String(body.kind),clean(body.category,50)||'资料',clean(body.note,2000),url,created).run();
}else return reply({error:'不支持的操作。'},400);
return reply({id},201);
}catch{return fail();}
}
export async function PATCH(req:Request){
const user=await identity(req);if(!user)return reply({error:'请先登录。'},401);
try{const body=await req.json() as Record<string,unknown>;
if(body.action==='edit'){const title=clean(body.title),url=clean(body.url,2000);let parsed:URL;try{parsed=new URL(url);}catch{return reply({error:'请输入有效网址。'},400);}if(!title||!['https:','http:'].includes(parsed.protocol))return reply({error:'请输入名称及有效网址。'},400);
const updated=await env.DB!.prepare("UPDATE resources SET title=?,url=?,category=?,note=? WHERE id=? AND owner=? AND kind IN ('link','tool')").bind(title,url,clean(body.category,50)||'其他',clean(body.note,2000),clean(body.id),user.userId).run();
return updated.meta.changes?reply({ok:true}):reply({error:'工具不存在。'},404);}
const result=await env.DB!.prepare('UPDATE resources SET favorite=? WHERE id=? AND owner=?').bind(body.favorite?1:0,clean(body.id),user.userId).run();return result.meta.changes?reply({ok:true}):reply({error:'资料不存在。'},404);}catch{return fail();}
}
export async function DELETE(req:Request){
const user=await identity(req);if(!user)return reply({error:'请先登录。'},401);
try{const body=await req.json() as Record<string,unknown>,id=clean(body.id);
if(body.kind==='course'){await env.DB!.batch([env.DB!.prepare("UPDATE resources SET course='' WHERE course=? AND owner=?").bind(id,user.userId),env.DB!.prepare('DELETE FROM courses WHERE id=? AND owner=?').bind(id,user.userId)]);}
else{const row=await env.DB!.prepare('SELECT object_key FROM resources WHERE id=? AND owner=?').bind(id,user.userId).first<{object_key:string}>();
if(!row)return reply({error:'资料不存在。'},404);
if(row.object_key)await env.BUCKET!.delete(row.object_key);
await env.DB!.prepare('DELETE FROM resources WHERE id=? AND owner=?').bind(id,user.userId).run();}
return reply({ok:true});}catch{return fail();}
}

