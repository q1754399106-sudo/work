import {createRoot} from 'react-dom/client';
import Desk from './study-desk';
createRoot(document.getElementById('root')!).render(<Desk/>);
